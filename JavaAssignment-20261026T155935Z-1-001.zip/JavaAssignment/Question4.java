import java.util.*;

class Product {
    private String productName;
    private double price;
    private int quantity;

    public Product(String productName, double price, int quantity) {
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }

    public double getTotal() {
        return price * quantity;
    }

    public String toString() {
        return productName + " x" + quantity +
               " = " + getTotal();
    }
}

class Order {
    private String orderId;
    private List<Product> products;

    public Order(String orderId) {
        this.orderId = orderId;
        products = new ArrayList<>();
    }

    public void addProduct(Product p) {
        products.add(p);
    }

    public double calculateTotal() {
        double total = 0;

        for (Product p : products) {
            total += p.getTotal();
        }

        return total;
    }

    public String toString() {
        String result = "Order ID: " + orderId + "\n";
        result += "Products:\n";

        for (Product p : products) {
            result += p + "\n";
        }

        result += "Total: " + calculateTotal();

        return result;
    }
}

public class Question4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String orderId = sc.nextLine();
        int n = Integer.parseInt(sc.nextLine());

        Order order = new Order(orderId);

        for (int i = 0; i < n; i++) {
            String[] data = sc.nextLine().split(",");

            Product p = new Product(
                data[0],
                Double.parseDouble(data[1]),
                Integer.parseInt(data[2])
            );

            order.addProduct(p);
        }

        System.out.println(order);

        sc.close();
    }
}